package jit.cse.vadya;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class vadyaView extends AppCompatActivity {
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private Adapter adapter;
    List<vadyaModel> vadya_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vadya_view);
        initData();
        initRecycler();

    }

    private void initData() {
        vadya_list.clear();
        try{
            InputStream is = getAssets().open("vaadya_data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer,"UTF-8");
            JSONArray data = new JSONArray(text);
            for(int i=0;i<data.length();i++){
                JSONObject d = data.getJSONObject(i);
                vadyaModel vd = new vadyaModel(d.getString("id"),
                        d.getString("name"),
                        d.getString("PrimaryType"),
                        d.getString("SecondaryType"),
                        d.getBoolean("isAvailable"),
                        (String[]) d.get("saleCategory"));
                vadya_list.add(vd);
            }
        }catch(Exception e){
            e.printStackTrace();
        }


    }

    private void initRecycler() {
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Adapter(vadya_list);
        adapter.notifyDataSetChanged();
    }
}