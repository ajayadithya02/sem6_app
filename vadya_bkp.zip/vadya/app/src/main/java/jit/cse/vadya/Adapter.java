package jit.cse.vadya;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    List<vadyaModel> vadyaList;

    public Adapter (List<vadyaModel> vadyaList){
        this.vadyaList = vadyaList;
    }
    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.vadya_card,parent,false);
        return new ViewHolder(view);
        //return null;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        String name = vadyaList.get(position).getName();
        String type = vadyaList.get(position).getType();
        String stype = vadyaList.get(position).getStype();

        holder.setData(name,type,stype);

    }

    @Override
    public int getItemCount() {
        return vadyaList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView v_img;
        private TextView v_name;
        private TextView v_type;
        private TextView v_stype;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            v_img = itemView.findViewById(R.id.v_img);
            v_name = itemView.findViewById(R.id.v_name);
            v_type = itemView.findViewById(R.id.v_type);
            v_stype = itemView.findViewById(R.id.v_stype);


        }

        public void setData(String name, String type, String stype) {
            if(name.equalsIgnoreCase("veena")){
                v_img.setImageResource(R.drawable.veena);
            }else if (name.equalsIgnoreCase("violin")){
                v_img.setImageResource(R.drawable.violin);
            }else if(name.equalsIgnoreCase("mridangam")){
                v_img.setImageResource(R.drawable.mridangam);
            }else if(name.equalsIgnoreCase("flute")){
                v_img.setImageResource(R.drawable.flute);
            }else{
                v_img.setImageResource(R.drawable.qmark);
            }

            v_name.setText(name);
            v_type.setText(type);
            v_stype.setText(stype);
        }
    }
}
